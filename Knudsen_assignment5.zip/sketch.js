let y;
let num = 14;

var mx = 510;
var my = 70;
var radius = 20;

var rx = 501;
var ry = 270;
var rw = 55;
var rh = 20;

var ex = 530;
var ey = 320;
var ew = 30;
var eh = 30;

let value = 0;


function setup() {
  createCanvas(600, 400);
  
}

function draw() {
  background(245, 217, 91);
  
  //Screen
  stroke(0);
  strokeWeight(18);
  fill(54, 54, 245);
  rect(50,50,400,300);
  
  //feet
  noStroke();
  fill(0);
  //x1, y1, x2, y2, x3, y3
  triangle(150, 350, 50, 390, 120, 350);
  triangle(350, 350, 450, 390, 380, 350);
  
  //remote
  fill(190);
  rect(490, 50, 80, 300, 20);
  
  //turn on/off button
  fill(245, 89, 69);
  ellipse(mx, my, radius, radius);
  
  var d = dist(mouseX, mouseY, mx, my);
  
 if (keyIsPressed) {
		
		if (key == 'x') {
				
				if (d < radius) {
                  
				fill(42, 245, 146);

				} else {
				
				fill (245, 89, 69);
				
				}
		}
	}

  ellipse(mx, my, radius, radius);
  
  
  //buttons for look - maybe use forloop
  fill(0);
  y = 95;
  for (let i = 0; i < num / 2; i++) {
    rect(500, y, 25, 15, 20);
    y += 25;
  }
  y = 95;
  for (let i = 0; i < num / 2; i++) {
    rect(532, y, 25, 15, 20);
    y += 25;
  }
  
  //button 2
  fill(0);
  rect(rx, ry, rw, rh, 20);
  
  if ((mouseX > rx) && (mouseX < rx+rw) && (mouseY > ry) && (mouseY < ry+rh) && (mouseIsPressed == true)) {
		
		fill(255, 67, 245);
        rect(125,160,250,80);
    
        fill(42, 245, 146);
        textSize(32);
        text('STREAMING', 155, 210);
        
	}

	else {

		fill (0);

	}
	
	rect(rx, ry, rw, rh, 20);
  
  //button 3
  fill(100);
  ellipse(ex, ey, ew, eh);

  if ((mouseX > ex) && (mouseX < ex+ew) && (mouseY > ey) && (mouseY < ey+eh) && (mouseIsPressed == true)) {
		
        fill(255, 67, 245);
        rect(125,125, 250,150);
    
        fill(42, 245, 146);
        textSize(32);
        text('MENU', 200, 170);
    
        textSize(20);
        text('SOUND', 150, 210);
        rect(240,198,80,10);
        
        textSize(20);
        text('LIGHT', 150, 230);
        rect(240,218,100,10);
    
	}
	else {
		fill (100);
    }
  ellipse(ex, ey, ew, eh);
}
