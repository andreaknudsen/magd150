let cloudx = 100;
let cloudy = 100;

let birdx = 50;
let birdy = 50;

function setup() {
  createCanvas(700, 400);
  
}

function draw() {
  background(135,206,235);
  
  //SUN
  sun(630, 70);
  
  /*
  noStroke();
  fill(255, 255, 51);
  //body
  circle(630, 70, 70);
  //lines around sun
  rect(625, 110, 5, 20);
  */
  
  //clouds
  for (var x = -45; x < width + 50; x += 150) {
        cloud(x, -10);
        scale(1.2);
        cloud(x+70, 90);
	}
  raindrops(0,0);
  
  scale(1.2)
  raindrops(0+50,0+1);
  
  scale(1.2)
  raindrops(0+100,0+2);
  
  scale(1);
  raindrops(0+16,0+20);
  
  scale(1.2)
  raindrops(0+58,0+21);
  
  scale(0.50);
  bird(birdx, birdy);
  birdx+=0.1;
  
  print(birdx);
  
}
  function cloud(x,y) {
    push(); // create a new drawing state
	translate(x, y);
	fill(250)
    noStroke();
    ellipse(cloudx, cloudy, 70, 50);
    ellipse(cloudx + 10, cloudy + 10, 70, 50);
    ellipse(cloudx - 20, cloudy + 10, 70, 50);
	pop(); // return the drawing state to it's original state, before       the push() function

}

function rain(rx,ry) {
    push(); 
	translate(rx, ry);
	fill(126,186,222)
    noStroke();
    //x1, y1, x2, y2, x3, y3
    triangle(71, 100, 75, 90, 79, 100);
    //x, y, w, [h]
    ellipse(75, 100, 7.7, 7);
	pop();
}

function raindrops(rainx, rainy) {
  push(); 
  translate(rainx, rainy);
  scale(0.35);
  for (var rainx = -50; rainx < 10; rainx += 10) {
        rain(rainx,35);
        rain(rainx,50);
        rain(rainx,65);
	}
  pop();
}


function sun (sx, sy) {
  push();
  noStroke();
  fill(255, 255, 51);
  circle(630, 70, 70);
  
  angleMode(DEGREES); // Change the mode to DEGREES
  let a = atan2(mouseY - height / 2, mouseX - width / 2);
  translate(sx, sy);
  
  
  angleMode(RADIANS); // Change the mode to RADIANS
  rotate(a); // variable a stays the same
  rect(-70, -5, 20, 5);
 
  pop();
   
  
}

function bird (birdx,birdy) {
  
	push ();
    translate(birdx, birdy);
    noStroke();
	fill(100);
	noStroke();
    triangle(birdx, birdy+10, birdx, birdy-10, birdx+5, birdy);
    ellipse(birdx, birdy, 20, 3);
    pop ();
    
 
}