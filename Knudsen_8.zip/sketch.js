let img1
let img2
let img3
let img4
var myFont;

var quote = "Spongebob is out on a walk through Bikinibottom with Patrick. They were having a bad day, but then they saw a butterfly! Move the mouse to make the butterfly fly around and keep them happy!";

function preload() {
	img1 = loadImage('bikinibottom.jpeg');
	img2 = loadImage('spongebob.png');
	img3 = loadImage('butterfly.gif');
    img4 = loadImage('patrickstar.png');
	myFont = loadFont('KrabbyPatty.ttf');
	
}

function setup() {
	createCanvas(1000, 500);
}

function draw() {
	background(220);

	
	image(img1, 0,0);
	image(img2, 0,mouseY/2);
    image(img4, 650, 100);
	image(img3, mouseX-90, mouseY-90);
    
	
	img1.resize(1000, 600);
	img3.resize(150,150);
    img4.resize(350,350);

    textFont(myFont);
    noStroke();
	fill(255);
	textSize(70);
    text("Spongebob Sqaurepants", 10, 60);

    textFont("Helvetica");
    stroke(5);
	textSize(20);
    text(quote, 425, 290, 250, 300);

}